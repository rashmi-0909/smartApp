import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showtypemaster',
  templateUrl: './showtypemaster.component.html',
  styleUrls: ['./showtypemaster.component.css']
})
export class ShowtypemasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

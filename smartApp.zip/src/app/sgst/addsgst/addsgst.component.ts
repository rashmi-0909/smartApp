import { Component, OnInit,Input } from '@angular/core';
import {AuthService} from 'src/app/auth/auth.service';
// import { Component, Input } from '@angular/core'
import { Router } from '@angular/router';
import { Routes, RouterModule } from '@angular/router';


@Component({
  selector: 'app-addsgst',
  templateUrl: './addsgst.component.html',
  styleUrls: ['./addsgst.component.css']
})
export class AddsgstComponent implements OnInit {
  formData: any = {};
  

  errors: any = [];

  constructor(private auth: AuthService,private router: Router) { }
  @Input() sgst:any;
  SgstId:string;
  SgstDetail:string;
  SgstRate:string;
  ngOnInit(): void {
    this.SgstId=this.SgstId;
    this.SgstDetail=this.SgstDetail;
    this.SgstRate=this.SgstRate;
  }


  addsgst(): void {
    console.log(this.formData);
    this.errors = [];

    this.auth.addSgst(this.formData)
      .subscribe((res:any ) => {
        if(res.succeded)
         console.log(res.data);
        this.router.navigate(['/showsgst'], { queryParams: { registered: 'success' } });
       },
        (errorResponse) => {
          this.errors.push(errorResponse.error.error);
          console.log(this.errors);
        });
        
   
  }










}

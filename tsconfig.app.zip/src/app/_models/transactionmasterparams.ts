export class TransactionmasterParams {
    
    pageNumber = 1;
    pageSize = 10;
    orderBy = 'trxId';
}
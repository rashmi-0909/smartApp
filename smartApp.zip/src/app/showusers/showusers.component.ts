import { Component, OnInit } from '@angular/core';

 import {NgForm} from '@angular/forms'  
 import {FormsModule} from '@angular/forms'  
import { Observable } from 'rxjs';

import 'rxjs/add/operator/do';  
import 'rxjs/add/operator/filter';  
import 'rxjs/add/operator/map';  
import { map } from 'rxjs/operator/map';
import {UserserviceService}from '../userservice.service';  
import {Users}from'./users';

@Component({
  selector: 'app-showusers',
  templateUrl: './showusers.component.html',
  styleUrls: ['./showusers.component.css']
})
export class ShowusersComponent implements OnInit {
 
  CompCode:string="";
  UserName:string="";
  UserEmailId:string="";
  UserPassword="";
  // id:string="";
  status:boolean=false;
  FormHeader="";
  editCustomer:boolean=false;
 //Users:Observable<Users>
test:any[];
  userlist:Users[];
mappedlist:Users[]=[];
  Dummyuser:Users;




  constructor(private service:UserserviceService) { }

  ngOnInit(): void {
    this.service.getUser().subscribe((tempdate) =>{  this.userlist=tempdate;})  
    ,err=>{  
      console.log(err);  
    }  
    ,err=>{  
      console.log(err);  
    }  


  }
/* 

  ShowRegForm=function(Users)
  {
    this.editCustomer=true;
    if(Users!=null)
    {
      this.SetValuesForEdit(Users)
    
    }
    else{
      this.ResetValues();
    }
  }


ResetValues(){
  this.CompCode="";
  this.UserName="";
  this.UserEmailId="";
  this.UserPassword="";
  this.FormHeader="Add"
}



Save(regForm:NgForm)
{
  this.GetDummyObject(regForm);

  switch(this.FormHeader)
  {
  case "Add":
         this.Adduser(this.Dummyuser);
  break;
  case "Edit":
        this.Updateuser(this.Dummyuser);
  break;
  case "Delete":
        this.Deleteuser(this.Dummyuser);
  break;
         default:
  break;

  }
}

GetDummyObject(regForm:NgForm):Users
{
  this.Dummyuser=new 

  this.Dummyuser.CompCode=regForm.value.CompCode;
  this.Dummyuser.UserName=regForm.value.UserName;
  this.Dummyuser.UserEmailId=regForm.value.UserEmailId;
  this.Dummyuser.UserPassword=regForm.value.UserPassword;

  return this.Dummyuser;
}
  Adduser(u: Users)
  {
    this.service.AddUser(this.Dummyuser).subscribe(res=>
      {
        this.userlist.push(res);
        alert("Data added successfully !! ")
        this.editCustomer=false;
      })
      ,err=>
      {
        console.log("Error Occured " + err);
      }
  }




 */









}

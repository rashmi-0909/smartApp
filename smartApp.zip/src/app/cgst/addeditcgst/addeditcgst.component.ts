import { Component, OnInit,Input } from '@angular/core';
import {AuthService} from 'src/app/auth/auth.service';
// import { Component, Input } from '@angular/core'
import { Router } from '@angular/router';
import { Routes, RouterModule } from '@angular/router';


@Component({
  selector: 'app-addeditcgst',
  templateUrl: './addeditcgst.component.html',
  styleUrls: ['./addeditcgst.component.css']
})
export class AddeditcgstComponent implements OnInit {
  formData: any = {};
  

  errors: any = [];




  constructor(private auth: AuthService,private router: Router) { }

  @Input() cgst:any;
  CgstId:string;
  CgstDetail:string;
  CgstRate:string;
  ngOnInit(): void {
    this.CgstId=this.CgstId;
    this.CgstDetail=this.CgstDetail;
    this.CgstRate=this.CgstRate;
  }

  addcgst(): void {
    console.log(this.formData);
    this.errors = [];

    this.auth.addCgst(this.formData)
      .subscribe((res:any ) => {
        if(res.succeded)
         console.log(res.data);
        this.router.navigate(['/showcgst'], { queryParams: { registered: 'success' } });
       },
        (errorResponse) => {
          this.errors.push(errorResponse.error.error);
          console.log(this.errors);
        });
        
   
  }

  editCgst(){
    var val = {CgstId:this.CgstId,
      CgstDetail:this.CgstDetail,
      CgstRate:this.CgstRate
    };
    
    this.auth.editCgst(val).subscribe(res=>{
    alert(res.toString());
    });
  }


}

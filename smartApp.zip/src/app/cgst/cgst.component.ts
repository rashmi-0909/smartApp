import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';





@Component({
  selector: 'app-cgst',
  templateUrl: './cgst.component.html',
  styleUrls: ['./cgst.component.css']
})
export class CgstComponent implements OnInit {

  constructor() { }
     
  ngOnInit(): void {
  }

     

}

export interface Users {
    CompCode:string;  
    UserName:string;  
    UserEmailId:string; 
    UserPassword:string; 
    



}

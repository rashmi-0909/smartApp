import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sgst',
  templateUrl: './sgst.component.html',
  styleUrls: ['./sgst.component.css']
})
export class SgstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

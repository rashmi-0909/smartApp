import { Component, OnInit } from '@angular/core';
;
@Component({
  selector: 'app-typemaster',
  templateUrl: './typemaster.component.html',
  styleUrls: ['./typemaster.component.css']
})
export class TypemasterComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
  }







}

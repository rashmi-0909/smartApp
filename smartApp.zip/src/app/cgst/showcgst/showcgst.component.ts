import { Component, OnInit } from '@angular/core';
import{AuthService} from 'src/app/auth/auth.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-showcgst',
  templateUrl: './showcgst.component.html',
  styleUrls: ['./showcgst.component.css']
})
export class ShowcgstComponent implements OnInit {

  constructor(private service:AuthService) { }
  
  ModalTitle:string;
  ActivateAddEditCgstComp:boolean=false;
  cgst:any;

  
 
 
  CgstList:any=[];
  
  ngOnInit(): void {
    this.refreshCgstList();
  }
     
  refreshCgstList(){
    this.service.getCgstList().subscribe(data=>{
     this.CgstList=data as any[];
   



     
    });
   
   }
      

   addClick(){
    this.cgst={
      CgstId:0,
     CgstDetail:"",
     CgstRate:""
    }
    this.ModalTitle="Add Record For Cgst";
    this.ActivateAddEditCgstComp=true;

  }





}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cgst-detail',
  templateUrl: './cgst-detail.component.html',
  styleUrls: ['./cgst-detail.component.css']
})
export class CgstDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

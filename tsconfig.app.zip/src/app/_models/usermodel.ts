export interface UserModel {
    compCode: string;
    userName: string;
    userEmailId: string;
    userPassword: string;
    token: string;
}
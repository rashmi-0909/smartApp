import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProfileComponent } from './profile/profile.component';
import { HomeComponent } from './home/home.component';
import{CgstComponent}from './cgst/cgst.component';
import{ShowcgstComponent}from'./cgst/showcgst/showcgst.component';
import{DashboardComponent}from'./dashboard/dashboard.component';
import{ShowusersComponent}from'./showusers/showusers.component';
import{ AddeditcgstComponent }from './cgst/addeditcgst/addeditcgst.component';
import{SgstComponent}from'./sgst/sgst.component';
import{ShowsgstComponent}from './sgst/showsgst/showsgst.component';
import{AddsgstComponent}from './sgst/addsgst/addsgst.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'profile', component: ProfileComponent },
  {path:'cgst',component:CgstComponent},
  {path:'showcgst',component:ShowcgstComponent},
  {path:'addcgst',component:AddeditcgstComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'showusers',component:ShowusersComponent},

 {path:'sgst',component:SgstComponent},
 {path:'showsgst',component:ShowsgstComponent},
 {path:'addsgst',component:AddsgstComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
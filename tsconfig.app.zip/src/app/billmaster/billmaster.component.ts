import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billmaster',
  templateUrl: './billmaster.component.html',
  styleUrls: ['./billmaster.component.css']
})
export class BillmasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

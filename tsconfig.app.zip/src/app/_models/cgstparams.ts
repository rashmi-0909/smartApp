export class CgstParams {
    pageNumber = 1;
    pageSize = 10;
    orderBy = 'cgstId';
}
 
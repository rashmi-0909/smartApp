export class SgstParams {
    pageNumber = 1;
    pageSize = 10;
    orderBy = 'sgstId';
}
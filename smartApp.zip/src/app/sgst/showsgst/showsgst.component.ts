import { Component, OnInit } from '@angular/core';
import{AuthService} from 'src/app/auth/auth.service';
import { RouterModule } from '@angular/router';




@Component({
  selector: 'app-showsgst',
  templateUrl: './showsgst.component.html',
  styleUrls: ['./showsgst.component.css']
})
export class ShowsgstComponent implements OnInit {

  constructor(private service:AuthService) { }

 
  CgstList:any=[];
  
  ngOnInit(): void {
    this.refreshCgstList();
  }
     
  refreshCgstList(){
    this.service.getCgstList().subscribe(data=>{
     this.CgstList=data as any[];
   



     
    });
   
   }
      


}

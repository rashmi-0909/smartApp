import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';

// import { AuthModule } from './auth/auth.module';
import { RouterModule } from '@angular/router';
import{AuthModule}from './auth/auth.module';
import{HttpClientModule,HttpHeaders}from '@angular/common/http';
import{FormsModule,ReactiveFormsModule}from'@angular/forms';
import { CgstComponent } from './cgst/cgst.component';
import { ShowcgstComponent } from './cgst/showcgst/showcgst.component';
import { AddeditcgstComponent } from './cgst/addeditcgst/addeditcgst.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import{SharedService}from 'src/app/shared.service';
import { map } from 'rxjs/operators';
import { ShowusersComponent } from './showusers/showusers.component';
import { SgstComponent } from './sgst/sgst.component';
import { ShowsgstComponent } from './sgst/showsgst/showsgst.component';
import { AddsgstComponent } from './sgst/addsgst/addsgst.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ProfileComponent,
    CgstComponent,
    ShowcgstComponent,
    AddeditcgstComponent,
    DashboardComponent,
    ShowusersComponent,
    SgstComponent,
    ShowsgstComponent,
    AddsgstComponent,
    
 
  ],
  imports: [ RouterModule,
    BrowserModule,
    AppRoutingModule,
    AuthModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
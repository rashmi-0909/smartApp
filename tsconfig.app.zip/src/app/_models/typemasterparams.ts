export class TypemasterParams {
    compCode: "";
    AccYear: "";
    pageSize: 10;
    pageNumber: 1;
    searchBy: "";
	  orderBy:"trxCd";
}

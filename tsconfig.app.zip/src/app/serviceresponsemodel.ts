export interface Serviceresponsemodel {
    data: Array<object>;
    success: boolean;
    message: string;


}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbillmaster',
  templateUrl: './addbillmaster.component.html',
  styleUrls: ['./addbillmaster.component.css']
})
export class AddbillmasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class IgstParams {
    pageNumber = 1;
    pageSize = 10;
    orderBy = 'igstId';
}
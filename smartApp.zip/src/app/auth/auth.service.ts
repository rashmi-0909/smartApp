import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import * as moment from 'moment';
import { map } from 'rxjs/operators';
// import { Http, Headers, RequestOptions} from '@angular/common/http';




 const jwt = new JwtHelperService();
 class DecodedToken {
  exp: number;
  username: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  // private uriseg = 'http://localhost:9000/api/v1/User/Add';
   private decodedToken;
  constructor(private http: HttpClient) { }
    readonly baseURL='http://localhost:9000/api/v1';

  public register(userData: any): Observable<any> {
    //  const URI = this.baseURL +'/User/Add';
    return this.http.post(this.baseURL+'/User/Add', userData);

     

    
  }
  public login(userData: any): Observable<any> {
   
    

    return this.http.post(this.baseURL+'/User/Login', userData).pipe(map(token => {
      return this.saveToken(token);
      
    }));
  }

  private saveToken(token: any): any {
    this.decodedToken = jwt.decodeToken(token);
    localStorage.setItem('auth_tkn', token);
    localStorage.setItem('auth_meta', JSON.stringify(this.decodedToken));
    return token;
    console.log(this.decodedToken);
  }
  public logout(): void {
    localStorage.removeItem('auth_tkn');
    localStorage.removeItem('auth_meta');

    this.decodedToken = new DecodedToken();
  }

//User Service
getUserList():Observable<any[]>{
  // console.log('service started');
  return this.http.get<any>(this.baseURL+'/User/GetAll');
}



//cgst service

      getCgstList():Observable<any[]>{
        console.log('service started');
        return this.http.get<any>(this.baseURL+'/CgstMaster/GetAll');
      }
      addCgst(userData: any): Observable<any>{
        return this.http.post(this.baseURL+'/CgstMaster/Add',userData);
      }
      editCgst(val:any){
        return this.http.put<any>(this.baseURL+'/CgstMaster/Edit',val);
      }
      deleteCgst(val:any){
        return this.http.post<any>(this.baseURL+'CgstMaster/0',val);
      }
     
      

 //sgst service

 getSgstList():Observable<any[]>{
  console.log('service started');
  return this.http.get<any>(this.baseURL+'/SgstMaster/GetAll');
}




  addSgst(userData: any): Observable<any>{
   return this.http.post(this.baseURL+'/SgstMaster/Add',userData);
 }
 








}